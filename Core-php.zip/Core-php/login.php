<?php
include('conn.php');
if(isset($_POST['Login']))
{
	$email = $_POST['email'];
	$password = $_POST['password'];

	$sql="SELECT * FROM `user` WHERE `email`= '$email' AND `password`='$password'";
	$ex=$conn->query($sql);
	$res =mysqli_fetch_object($ex);

	if($ex->num_rows > 0)
	{
		session_start();
		$_SEESION['user_id']=$res->user_id;
		$_SEESION['fname']=$res->fname;
		$_SEESION['lname']=$res->lname;
		$_SEESION['gender']=$res->gender;
		$_SEESION['mno']=$res->mno;
		$_SEESION['city']=$res->city;
		$_SEESION['hobbies']=$res->hby;
		$_SEESION['email']=$res->email;
		$_SEESION['password']=$res->password;
		header('Location:profile.php');
	}
	else
	{
		echo "check username and password";
	}
}
//seesion_start();
?>
<form method="POST">
	<label>Email</label>
	<input type="text" name="email"><br>
	<label>Password</label>
	<input type="password" name="password"><br>
	<input type="submit" name="Login" value="Login">
</form>
