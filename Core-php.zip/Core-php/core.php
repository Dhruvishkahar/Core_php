<?php
include('conn.php');
if(isset($_POST['Registration']))
{
	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$gender=$_POST['gender'];
	$mno=$_POST['mno'];
	$city=$_POST['city'];
	 $hby =  implode(',',$_POST['hby']);
   // echo $hby; exit();
 	$email = $_POST['email'];
    $password = $_POST['password'];
    $image = $_FILES['image']['name'];
    $type = $_FILES['image']['type'];
    $size = $_FILES['image']['size'];
    $tmp_name = $_FILES['image']['tmp_name'];
    $new_path = ('upload/'.$image);
    move_uploaded_file($tmp_name,$new_path);

	$sql="INSERT INTO `user` (`fname`,`lname`,`gender`,`mno`,`city`,`hobbies`,`email`,`password`,`image`)VALUES('$fname','$lname','$gender','$mno','$city','$hby','$email',$password,'$image')";
	$ex = $conn->query($sql);
	if($ex)
	{
		echo "RECORD INSERTED";
	}
	else
	{
		echo "ERROR";
	}
}
$city = "SELECT * FROM `city`";
$ex1 = $conn->query($city);
?>


<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
</head>
<body>
	<table border="1" cellpadding="10" cellspacing="10" align="center">

		<form method="POST" enctype="multipart/form-data">
		
			<h1 align="center"><u>Registration Form</u></h1>
		
				<td>
					<label>First Name</label>
				</td>
				<td>
					<input type="text" name="fname">
				</td>
			</tr>
			<tr>
				<td>
					<label>Last Name</label>
				</td>
				<td>
					<input type="text" name="lname">
				</td>
			</tr>
			<tr>
				<td>
					<label>Gender</label>
				</td>
				<td>
					<input type="radio" name="gender" value="male">male
					<input type="radio" name="gender" value="female">female
				</td>
			</tr>
			<tr>
				<td>
					<label>Moblie No</label>
				</td>
				<td>
					<input type="text" name="mno">
				</td>
			</tr>
			<tr>
				<td>
					<label>City</label>
				</td>
				<td>
					<select name="city">
						<option><--please select city--></option>
						<?php while($city = mysqli_fetch_object($ex1)){ ?>

<option value="<?php echo $city->city_id  ?>">  <?php echo $city->city_name  ?> </option>

	<?php  }  ?>
	
					
						</select>
				</td>
			</tr>
			<tr>
				<td>
					<label>Hobbies</label>
				</td>
				<td>
					<input type="checkbox" name ="hby[]" value="php" >PHP
					<input type="checkbox" name ="hby[]" value="asp.net" >ASP.NET
					<input type="checkbox" name ="hby[]" value="java" >JAVA 
				</td>
			</tr>
			<tr>
				<td>
					<label>Email</label>
				</td>
				<td>
					<input type="text" name="email">
				</td>
			</tr>
			<tr>
				<td>
					<label>Password</label>
				</td>
				<td>
					<input type="Password" name="password">
				</td>
			</tr>
			<tr>
				<td>
					<label>Image</label>
				</td>
				<td>
					<input type="file" name="image">
				</td>
			</tr>
			<tr>
				
				<td colspan="3" align="center">
					<input type="submit" name="Registration" value="Registration">
					<input type="reset" name="reset" value="reset">
				</td>
			</tr>
		</form>
	</table>

</body>
</html>