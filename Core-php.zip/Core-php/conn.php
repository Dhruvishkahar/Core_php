<?php

$conn = new mysqli("localhost","root","","core_php");
if($conn)
{
	echo "DATABASE CONNECTED";
}
else
{
	echo "ERROR";
}




?>