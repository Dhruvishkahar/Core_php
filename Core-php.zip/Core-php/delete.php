<?php
include('conn.php');

 if(isset($_GET['del_id']))
 {
    $user_id = $_GET['del_id'];
   //echo $user_id;

    echo $sql ="DELETE FROM `user` WHERE `user_id` = '$user_id'";
    $ex = $conn->query($sql);

    if($ex)
    {
        header('location:table.php');
    }
    else
    {
        echo "Error";
    }
}

?>