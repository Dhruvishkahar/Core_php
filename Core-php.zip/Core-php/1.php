<?php
include('conn.php');

$sql = "SELECT * FROM `user` INNER JOIN `city` ON `user`.`city` = `city`.`city_id`";
$ex = $conn->query($sql);

?>
<html>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <h2 align="center" style="padding-top: 15px;"><u>Registration Data</u></h2>
	<table class="table" border="1" align="center" cellspacing="10" cellpadding="10">
		<thead>
		<tr >
			<th> Image </th>
			<th>id</th>
			<tH> fname </tH>
			<th> lname </tH>
				<th> Hobbies </tH>

					<th> City</th>
					
					<th colspan="2" > Action </th>
				</tr>
</thead>
<tbody>
				<?php while($res = mysqli_fetch_object($ex))
				{ ?>
				<tr>
					 <td>  <img src="upload/<?php echo $res->image; ?>" height="100px;" width="100px;">  </tD>
            
        <td> <?php echo $res->user_id; ?> </tD>
           <td> <?php echo $res->fname;  ?> </tD>
                <td> <?php echo $res->lname; ?></tD>
                   <td> <?php echo $res->city_name; ?> </td>
                  <td> <?php echo $res->hobbies; ?></tD>
                    <td> <?php echo $res->email; ?></tD>
                      <td> <?php echo $res->password; ?></tD>
                        <td><a href="delete?user_id=<?php echo $res->user_id; ?>"><button type="button" class="btn btn-delete">Delete</a> </button></td>
                        <td><a href="edit?user_id=<?php echo $res->user_id; ?>"> <button type="button" class="btn btn-edit">Edit</a></button></td>
									</tr>


									<?php }  ?>
</tbody>
								</table>
							
							<div>
							</body>
							</html>