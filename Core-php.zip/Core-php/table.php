<?php
include('conn.php');


$sql = "SELECT * FROM `user` INNER JOIN `city` ON `user`.`city` = `city`.`city_id`";
$ex = $conn->query($sql);
?>

<html>
<head>
  <title>Showdata</title>
  <!-- <meta charset="utf-8"> -->
  <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <h2 align="center" style="padding-top: 15px;"><u>Register Data</u></h2>
         
  <table class="table" align="center"cellspacing="25" cellpadding="25">
    <thead style="padding-left: 20px;">
      <tr>
        <th>Image</th>
      <th>ID</th>
    <th>fname</th>
    <th>lname</th>
    <th>Gender</th>
    <th>Mobile No</th>
    <th>city</th>
    <th>Hobbies</th>
    <th>Email</th>
    <th>Password</th>
    <th colspan="2" >Action</th>
    </tr>
</thead>
    <tbody>
      <tr>
      <?php while($res = mysqli_fetch_object($ex))
        { ?>
          <td>  <img src="upload/<?php echo $res->image; ?>" height="100px;" width="100px;">  </tD>
        <td> <?php echo $res->user_id; ?> </tD>
           <td> <?php echo $res->fname;  ?> </tD>
                <td> <?php echo $res->lname; ?></tD>
                  <td><?php echo $res->gender?></td>
                  <td><?php echo $res->mno?></td>
                   <td> <?php echo $res->city_name; ?> </td>
                  <td> <?php echo $res->hobbies; ?></tD>
                    <td> <?php echo $res->email; ?></tD>
                      <td> <?php echo $res->password; ?></tD>
                        <td><a href="delete.php?del_id=<?php echo $res->user_id; ?>"><button type="button" class="btn btn-delete">Delete</a> </button></td>
                        <td><a href="edit.php?edt_id=<?php echo $res->user_id; ?>"> <button type="button" class="btn btn-edit">Edit</a></button></td>
                   
      
      </tr>
       <?php }  ?>

                  </tbody>
  </table>
</div>

</body>
</html>