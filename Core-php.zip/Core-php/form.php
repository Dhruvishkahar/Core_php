

<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
</head>
<body>
	<center>
<form method="POST">
	<h1>REGISTATION FORM</h1>
<label>Fname</label>
<input type="text" name="fname"><br><br>
<label>lname</label>
<input type="text" name="lname"><br><br>
<label>Hobbies</label>
	<input type="checkbox" name ="hby[]" value="php" >PHP
	<input type="checkbox" name ="hby[]" value="asp.net" >ASP.NET
	<input type="checkbox" name ="hby[]" value="java" >JAVA <br><br>

	<label> Email </label>
	<input type="email" name="email" ><br><br>
	<label> password </label>
	<input type="password" name="password" ><br><br>
<input type="submit" name="submit" value="Registration"> 
</form>
	</center>
</body>
</html>