<?php
session_start();
if(empty($_SESSION['email']))
{
	header('Location:login.php');
}
?>


<html>
<head>
</head>
<body>
	<table border="2" align="center" cellspacing="10" cellpadding="10" style="background:#d9fdff;">
		<tr>
			<tH> Welome : <?php echo $_SESSION['fname'];  ?> </th>
				<td>
					<a href="logout"> Logout </a>
				</td>
			</tr>

			<tr >
				<th> Image </th>
				<th>id</th>
				<tH> fname </tH>
				<th> lname </tH>
					<th> Hobbies </tH>
						<th> City</th>

					<!-- <th> City</th>
					
					<th colspan="2" > Action </th> -->
				</tr>

				
				<tr>
					<td>  <img src="upload/<?php echo $_SESSION['image']; ?>" height="100px;" width="100px;">  </tD>
						<td> <?php echo $_SESSION['user_id']; ?> </tD>
							<td> <?php echo $_SESSION['name'];  ?> </tD>
								<td> <?php echo $_SESSION['lname'];  ?> </tD>
									<td> <?php echo $_SESSION['hobby']; ?></tD>

										<td> <?php echo $_SESSION['city']; ?> </td>
									</tr> 


									

								</table>
							</body>
							</html>