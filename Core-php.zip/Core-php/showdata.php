<?php
include('conn.php');


$sql = "SELECT * FROM `user` INNER JOIN `city` ON `user`.`city` = `city`.`city_id`";
$ex = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Showdata</title>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<table align="center" border="1" cellspacing="10" cellpadding="10" style="background-color:#abfbf3;">
	<tr>
		<th>ID</th>
		<th>fname</th>
		<th>lname</th>
		<th>Gender</th>
		<th>Mobile NO</th>
		<th>city</th>
		<th>Hobbies</th>
		<th>Email</th>
		<th>Password</th>

		<th colspan="2" > Action </th>

	</tr>
	<?php while($res = mysqli_fetch_object($ex))
				{ ?>
				<tr>
					 <td>  <img src="upload/<?php echo $res->image; ?>" height="100px;" width="100px;">  </tD> 
						<td> <?php echo $res->user_id; ?> </tD>
							<td> <?php echo $res->fname;  ?> </tD>
								<td> <?php echo $res->lname; ?></tD>
									<td><?php echo $res->gender?></td>
									<td><?php echo $res->mno?></td>
									<td> <?php echo $res->city_name; ?> </td>
									<td> <?php echo $res->hobbies; ?></tD>
										<td> <?php echo $res->email; ?></tD>
											<td> <?php echo $res->password; ?></tD>
										
										<td> <a href="delete?user_id=<?php echo $res->user_id; ?>"> Delete </a> </td>
										<td> <a href="edit?user_id=<?php echo $res->user_id; ?>">Edit</a> </td>
									</tr>


									<?php }  ?>
</table>
</body>
</html>