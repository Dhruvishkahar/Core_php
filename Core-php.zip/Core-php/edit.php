<?php
include('conn.php');
if(isset($_GET['edt_id']))
 {
    $user_id = $_GET['edt_id'];
    $sql = "SELECT * FROM `user` WHERE `user_id` = '$user_id'";
    $ex = $conn->query($sql);
   //  echo "<pre>";
   // print_r($ex);
    if(isset($_POST['update']))
    {
        $user_id = $_POST['user_id'];
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $gender = $_POST['gender'];
        $mno = $_POST['mno'];
        $city = $_POST['city'];
        $hby =  implode(',',$_POST['hby']);
        $email = $_POST['email'];
        $password = $_POST['password'];
      	if($_FILES['image']['name'])
        {
             $image = $_FILES['image']['name'];
             $type = $_FILES['image']['type'];
             $size = $_FILES['image']['size'];
             $tmp_name = $_FILES['image']['tmp_name'];
             $new_path = ('upload/'.$image);
             move_uploaded_file($tmp_name,$new_path);

        }
        else
        {
            $image = $_POST['old_image'];

        }
        $update = "UPDATE `user` SET `fname` = '$fname',`lname` = '$lname',`gender` = '$gender',`mno` = '$mno',`city`='$city',`hobbies` = '$hby',`email` = '$email',`password` = '$password',`image`='$image' WHERE `user_id` = '$user_id'";
        $ex1 = $conn->query($update);

        header('location:table.php');
    }

 }
?>




<?php while($res = mysqli_fetch_object($ex))


{ ?>

	<form method="POST">
		<label>id</label>
<input type="text" readonly name="user_id" value="<?php echo $res->user_id; ?>"><br>
<label>name</label>
<input type="text" name="fname" value="<?php echo $res->fname; ?>"><br>
<label>lname</label>
<input type="text" name="lname" value="<?php echo $res->lname; ?>"><br>
<label>gender</label>
<input type="text" name="gender" value="<?php echo $res->gender; ?>"><br>
<label>mobile no</label>
<input type="text" name="mno" value="<?php echo $res->mno; ?>"><br>
<label>city</label>
<select name="city">
	<?php 
			$cc = "SELECT * FROM `city`";
			$ex1 = $conn->query($cc);

	while($city = mysqli_fetch_object($ex1)){ ?>

<option <?php if($res->city == $city->city_id){  echo "selected"; }  ?>  value="<?php echo $city->city_id  ?>">  <?php echo $city->city_name  ?> </option>

	<?php  }  ?>
	
	</select> <br>
<label>Hobbies</label>
		<?php  $gg = explode(',' ,$res->hobbies); 
				//print_r($gg);
	    ?>
	<input type="checkbox" <?php  if(in_array('php',$gg) ){ echo "checked";  }  ?>  name ="hby[]" value="php" >PHP
	<input type="checkbox" <?php  if(in_array('asp.net',$gg) ){ echo "checked";  }  ?>  name ="hby[]" value="asp.net" >ASP.NET
	<input type="checkbox"  <?php  if(in_array('java',$gg) ){ echo "checked";  }  ?>  name ="hby[]" value="java" >JAVA <br>

<label>email</label>
<input type="text" name="email" value="<?php echo $res->email; ?>"><br>

<label>password</label>
<input type="text" name="password" value="<?php echo $res->password; ?>"><br>

<label> Current Image  </label>
	<input type="text" name="old_image" value="<?php echo $res->image ?>">
	<img src="upload/<?php  echo $res->image ?>" height="100px" width="100px"> <br>
	<label> change Image  </label>
	<input type ="file" name="image" ><br>





<input type="submit" name="update" value="Update">
</form>


<?php }
   ?>
